Title: Billing System.

About: It is a Application based on java. It is used to generate bills in the super market. The Software has 2 login page. 1)Manager Login. 2)Billing Login.

The manager will login into manager login and than he can see the bill details, can see the stock present in the market and he can add products to the database.

The employees working in the supermarket will login into billing login. They can than generate bills by simply entering the bill number, item number and the quantity. Add button will add the products into the bill and will deduct the quantity field of that product by quantity purchased, total button will print the total amount, bill number, date and time. Save button will save the bill in the folder ‘bills’ which is in C drive of the machine. The window has a menu bar and has 3 menu items. 1)About This will tell you about the project. 2)Help This will help you to use the software by opeing a html file named ‘Help.html’. 3)Exit To exit the software.

About Databse:

Microsoft Access is used as the database. The database ‘PROJECT’ contains 3 tables 1)ManagerLogin. 2)BillingLogin. 3)Product.

ManagerLogin has following fields • Username • Password The field contains username and password of manager of the supermarket.

BillingLogin has following fields • Usename • Password The fields contain username and password of all the employees. These employees will generate bills for the customer.

Product has following fields • ID • Product1 • Product2 • Quantity These fields contains product ID, Product1 contains product name, product2 contains mrp of the product and quantity contains the quantity of the product present in the supermarket.
